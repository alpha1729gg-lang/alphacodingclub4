
<?php
include 'db.php';
$result = $conn->query("SELECT * FROM pages");
$pages = [];
while($row = $result->fetch_assoc()){
    $pages[] = $row;
}
echo json_encode($pages);
?>
