
-- Database: web_builder
CREATE DATABASE IF NOT EXISTS web_builder;
USE web_builder;

-- جدول المستخدمين
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','member') DEFAULT 'member'
);

-- جدول الصفحات
CREATE TABLE pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT
);

-- جدول عناصر الصفحة
CREATE TABLE elements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_id INT NOT NULL,
    type VARCHAR(50),
    content TEXT,
    style TEXT,
    position VARCHAR(50),
    FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE
);
