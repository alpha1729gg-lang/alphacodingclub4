
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Web Builder</title>
<link rel="stylesheet" href="style.css">
<script src="script.js"></script>
</head>
<body>
<div class="header"><h1>Web Builder</h1></div>
<div id="pages"></div>
<script>
// تحميل الصفحات من قاعدة البيانات وعرضها
fetch('load_pages.php')
.then(res => res.json())
.then(pages => {
    let container = document.getElementById('pages');
    pages.forEach(page => {
        let div = document.createElement('div');
        div.innerHTML = '<h2>' + page.title + '</h2>';
        div.classList.add('element');
        makeDraggable(div);
        container.appendChild(div);
    });
});
</script>
</body>
</html>
